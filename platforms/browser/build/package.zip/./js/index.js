$("#btn-play").on("click",function() {
  window.plugins.nativepagetransitions.slide({
      "direction" : "left",
      "href" : "categories.html"
  });


});

$("#btn-acerca").on("click",function() {
  window.plugins.nativepagetransitions.slide({
      "direction" : "left",
      "href" : "acerca_de.html"
  });
});

$("#btn-loose").on("click",function() {
  window.plugins.nativepagetransitions.slide({
      "direction" : "left",
      "href" : "loose.html"
  });
});
