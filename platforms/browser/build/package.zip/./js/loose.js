$("#btn-back").on("click",function() {
  window.plugins.nativepagetransitions.slide({
      "direction" : "right",
      "href" : "index.html"
  });
});
